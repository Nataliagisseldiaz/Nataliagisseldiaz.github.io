package tp3java;


import java.util.Scanner;

public class ContarCifras {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un número entre 0 y 9999: ");
        int numero = scanner.nextInt();

        if (numero >= 0 && numero <= 9999) {
            int cifras = contarCifras(numero);
            System.out.println("El número " + numero + " tiene " + cifras + " cifras.");
        } else {
            System.out.println("El número no pertenece al rango solicitado (0-9999).");
        }

        scanner.close();
    }

    
    public static int contarCifras(int numero) {
        if (numero == 0) {
            return 1; 
        }

        int cifras = 0;
        while (numero > 0) {
            numero /= 10; 
            cifras++;
        }
        return cifras;
    }
}