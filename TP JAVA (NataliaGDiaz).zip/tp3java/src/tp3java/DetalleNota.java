package tp3java;

import java.util.Scanner;

public class DetalleNota {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese una nota: ");
        int nota = scanner.nextInt();

        System.out.print("Detalle: ");
        if (nota >= 0 && nota <= 3) {
            System.out.println("Insuficiente");
        } else if (nota == 4) {
            System.out.println("Suficiente");
        } else if (nota == 5 || nota == 6) {
            System.out.println("Bien");
        } else if (nota == 7 || nota == 8) {
            System.out.println("Notable");
        } else if (nota == 9 || nota == 10) {
            System.out.println("Sobresaliente");
        } else {
            System.out.println("Nota fuera de rango");
        }

        scanner.close();
    }
}